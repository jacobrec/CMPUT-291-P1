echo "SELECT expiry FROM registrations WHERE regno=16" | sqlite3 src/sql/test.db
echo "SELECT expiry FROM registrations WHERE regno=17" | sqlite3 src/sql/test.db

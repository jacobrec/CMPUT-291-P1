SELECT regno, fname, lname, expiry FROM registrations
    WHERE regno = :regno


INSERT INTO tickets (tno, regno, fine, violation, vdate) VALUES
    (:tno, :regno, :vamount, :vtext, :vdate);

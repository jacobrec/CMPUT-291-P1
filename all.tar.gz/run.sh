rlwrap racket src/main.rkt "$@"

